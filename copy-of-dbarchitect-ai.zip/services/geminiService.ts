
import { GoogleGenAI, Type } from "@google/genai";
import { SchemaData } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });

const SCHEMA_RESPONSE_TYPE = {
  type: Type.OBJECT,
  properties: {
    sql: {
      type: Type.STRING,
      description: "Complete SQL DDL script with indexing, constraints, defaults, and specifically audit/logging tables for monitoring and security trails.",
    },
    apiEndpoints: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          method: { type: Type.STRING, enum: ['GET', 'POST', 'PUT', 'DELETE', 'PATCH'] },
          path: { type: Type.STRING },
          summary: { type: Type.STRING },
          description: { type: Type.STRING },
          requestSchema: { type: Type.STRING },
          responseSchema: { type: Type.STRING },
          errorCodes: { type: Type.ARRAY, items: { type: Type.STRING } },
          rolesRequired: { type: Type.ARRAY, items: { type: Type.STRING }, description: "Required RBAC roles for this endpoint." }
        },
        required: ["method", "path", "summary", "description", "requestSchema", "responseSchema"]
      }
    },
    implementationCode: {
      type: Type.STRING,
      description: "Complete Node.js/Express controller logic including auth middleware and input validation.",
    },
    frontendCode: {
      type: Type.STRING,
      description: "A complete, modern React component using Tailwind CSS for the frontend UI.",
    },
    manual: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          title: { type: Type.STRING },
          content: { type: Type.STRING },
          audience: { type: Type.STRING, enum: ['Developer', 'Admin', 'End-User'] }
        },
        required: ["title", "content", "audience"]
      }
    },
    monitoring: {
      type: Type.OBJECT,
      properties: {
        strategy: { type: Type.STRING },
        metrics: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              name: { type: Type.STRING },
              target: { type: Type.STRING },
              threshold: { type: Type.STRING }
            },
            required: ["name", "target", "threshold"]
          }
        },
        healthChecks: { type: Type.ARRAY, items: { type: Type.STRING } }
      },
      required: ["strategy", "metrics", "healthChecks"]
    },
    errorHandling: {
      type: Type.OBJECT,
      properties: {
        strategy: { type: Type.STRING },
        standardResponse: { type: Type.STRING },
        errorCodes: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              code: { type: Type.STRING },
              httpStatus: { type: Type.INTEGER },
              message: { type: Type.STRING },
              description: { type: Type.STRING },
              mitigation: { type: Type.STRING }
            },
            required: ["code", "httpStatus", "message", "description", "mitigation"]
          }
        }
      },
      required: ["strategy", "standardResponse", "errorCodes"]
    },
    security: {
      type: Type.OBJECT,
      properties: {
        strategy: { type: Type.STRING, description: "Overall security posture and methodology." },
        authentication: { type: Type.STRING, description: "Details on how users are identified (e.g. JWT with RS256, OAuth2 Flow)." },
        authorization: { type: Type.STRING, description: "Details on access control (e.g. RBAC with hierarchy)." },
        encryptionStrategy: { type: Type.STRING, description: "Data at rest and in transit encryption details." },
        controls: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              name: { type: Type.STRING },
              type: { type: Type.STRING, enum: ['AuthN', 'AuthZ', 'Encryption', 'Network', 'Audit'] },
              description: { type: Type.STRING },
              implementation: { type: Type.STRING }
            },
            required: ["name", "type", "description", "implementation"]
          }
        }
      },
      required: ["strategy", "authentication", "authorization", "controls", "encryptionStrategy"]
    },
    entities: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          name: { type: Type.STRING },
          fields: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                name: { type: Type.STRING },
                type: { type: Type.STRING },
                isPrimary: { type: Type.BOOLEAN },
                isForeign: { type: Type.BOOLEAN },
                nullable: { type: Type.BOOLEAN },
                references: { type: Type.STRING },
              },
              required: ["name", "type", "isPrimary", "isForeign", "nullable"]
            }
          },
          indexes: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                name: { type: Type.STRING },
                columns: { type: Type.ARRAY, items: { type: Type.STRING } },
                type: { type: Type.STRING, enum: ['btree', 'fulltext', 'unique', 'hash'] }
              }
            }
          }
        },
        required: ["name", "fields"]
      }
    },
    relationships: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          fromTable: { type: Type.STRING },
          fromField: { type: Type.STRING },
          toTable: { type: Type.STRING },
          toField: { type: Type.STRING },
          type: { type: Type.STRING, enum: ['one-to-one', 'one-to-many', 'many-to-many'] }
        },
        required: ["fromTable", "fromField", "toTable", "toField", "type"]
      }
    },
    explanation: {
      type: Type.STRING,
    }
  },
  required: ["sql", "apiEndpoints", "implementationCode", "frontendCode", "entities", "relationships", "explanation", "manual", "monitoring", "errorHandling", "security"]
};

export async function generateSchema(prompt: string, history: any[] = []): Promise<SchemaData> {
  const model = 'gemini-3-pro-preview';
  
  const systemInstruction = `You are a world-class senior full-stack architect. You build entire system blueprints including Database, API, Frontend, Documentation, Monitoring, Error Management, and Robust Security.

CORE RESPONSIBILITIES:
1. Database Architecture: Normalized SQL with optimized indexing and AUDIT LOG tables.
2. API Security: Define JWT strategies, RBAC roles, and rate limiting requirements.
3. Security Design: Implement Zero-Trust principles. Define authentication flows, authorization logic, and data encryption (at rest and in transit).
4. Error Management: Robust codes with no PII or sensitive system info leaks.
5. Implementation Code: Must include security middleware and proper password hashing (bcrypt/argon2) where relevant.
6. Professional Design: Always use a clean, modern aesthetic.`;

  const response = await ai.models.generateContent({
    model,
    contents: [
      ...history,
      { parts: [{ text: prompt }] }
    ],
    config: {
      systemInstruction,
      responseMimeType: "application/json",
      responseSchema: SCHEMA_RESPONSE_TYPE,
      temperature: 0.1,
    },
  });

  return JSON.parse(response.text);
}
