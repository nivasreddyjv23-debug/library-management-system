
import React, { useState, useRef, useEffect } from 'react';
import { SchemaData, ChatMessage } from './types';
import { generateSchema } from './services/geminiService';
import ERDiagram from './components/ERDiagram';
import SqlEditor from './components/SqlEditor';
import ApiPreview from './components/ApiPreview';
import FrontendPreview from './components/FrontendPreview';
import DeploymentPreview from './components/DeploymentPreview';
import UatLab, { FeedbackEntry } from './components/UatLab';
import TrainingLab from './components/TrainingLab';
import MonitoringLab from './components/MonitoringLab';
import ErrorLab from './components/ErrorLab';
import SecurityLab from './components/SecurityLab';

const App: React.FC = () => {
  const [messages, setMessages] = useState<ChatMessage[]>([
    { role: 'assistant', content: 'Hello! I am your AI Architect. Describe your system requirements, and I will design the database schema, API, frontend, manual, monitoring, security protocols, and error handling strategy for you.' }
  ]);
  const [inputValue, setInputValue] = useState('');
  const [currentSchema, setCurrentSchema] = useState<SchemaData | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [view, setView] = useState<'diagram' | 'sql' | 'api' | 'frontend' | 'deploy' | 'uat' | 'training' | 'monitoring' | 'errors' | 'security'>('diagram');
  const [showToast, setShowToast] = useState(false);
  const [environment, setEnvironment] = useState<'staging' | 'production'>('staging');
  
  const chatEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleCopy = () => {
    setShowToast(true);
    setTimeout(() => setShowToast(false), 2000);
  };

  const runPrompt = async (prompt: string, customHistory?: any[]) => {
    if (isLoading) return;
    const userMsg: ChatMessage = { role: 'user', content: prompt };
    setMessages(prev => [...prev, userMsg]);
    setIsLoading(true);

    try {
      const history = customHistory || messages.map(m => ({
        role: m.role === 'user' ? 'user' : 'model',
        parts: [{ text: m.content }]
      }));

      const schema = await generateSchema(prompt, history);
      setCurrentSchema(schema);
      setMessages(prev => [...prev, { 
        role: 'assistant', 
        content: schema.explanation, 
        schema 
      }]);
    } catch (error) {
      console.error(error);
      setMessages(prev => [...prev, { role: 'assistant', content: 'I encountered an error while generating the architecture. Please try again.' }]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleRefineWithFeedback = async (feedback: FeedbackEntry[]) => {
    if (isLoading) return;
    
    const criticalIssues = feedback.filter(f => f.status !== 'PASS');
    if (criticalIssues.length === 0) return;

    const feedbackSummary = criticalIssues.map(f => `- [${f.role}] ${f.scenario}: ${f.comment}`).join('\n');
    const prompt = `Adjust the current system architecture based on the following UAT feedback from library staff:\n\n${feedbackSummary}\n\nUpdate the SQL schema, API endpoints, implementation code, and frontend UI to address these specific issues while maintaining existing functionality. Also regenerate documentation, security specs, and monitoring strategies.`;
    
    await runPrompt(prompt);
    setView('diagram');
    setEnvironment('staging');
  };

  const handlePromoteToProduction = () => {
    setEnvironment('production');
    setMessages(prev => [...prev, { 
      role: 'assistant', 
      content: 'Promoting architecture to production environment. Initiating zero-downtime cutover and scaling infrastructure. Advanced security policies and performance monitoring active.' 
    }]);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputValue.trim()) return;
    runPrompt(inputValue);
    setInputValue('');
  };

  const templates = [
    { name: 'Secure Library Auth', prompt: 'Design a library system with robust security. Implement JWT-based auth, password hashing with Argon2, and a multi-role RBAC system (Librarian, Member, Admin). Include security audit tables in the SQL schema.' },
    { name: 'Library Observability', prompt: 'Design a library system with a heavy focus on monitoring. Include audit logging tables, API request tracking middleware, and a monitoring strategy for high-availability database clusters.' },
    { name: 'Robust API Errors', prompt: 'Design a library management system with a comprehensive error handling strategy. Define codes for "OUT_OF_STOCK", "MEMBER_OVERDUE", and "INVALID_LOAN_TYPE".' },
  ];

  const getFrontendTitle = () => {
    if (!currentSchema) return "Component.tsx";
    const exp = currentSchema.explanation.toLowerCase();
    if (exp.includes('member') || exp.includes('auth')) return "MemberAuth.tsx";
    if (exp.includes('loan') || exp.includes('issue') || exp.includes('return')) return "LoanManagement.tsx";
    if (exp.includes('search')) return "SearchInterface.tsx";
    return "AppView.tsx";
  };

  return (
    <div className="flex h-screen bg-slate-950 text-slate-200 overflow-hidden relative">
      {/* Toast Notification */}
      <div className={`fixed top-8 left-1/2 -translate-x-1/2 z-[100] transition-all duration-300 transform ${showToast ? 'translate-y-0 opacity-100' : '-translate-y-12 opacity-0 pointer-events-none'}`}>
        <div className="bg-emerald-500 text-white px-4 py-2 rounded-full shadow-2xl shadow-emerald-500/20 text-xs font-bold flex items-center gap-2">
          <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" />
          </svg>
          Copied to clipboard!
        </div>
      </div>

      {/* Sidebar: Chat Refinement */}
      <div className="w-1/3 min-w-[380px] flex flex-col border-r border-slate-800 bg-slate-900/50 z-10">
        <div className="p-6 border-b border-slate-800 bg-slate-900 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-blue-600 rounded-lg flex items-center justify-center shadow-lg shadow-blue-900/20">
              <svg className="w-6 h-6 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 7v10c0 2.21 3.582 4 8 4s8-1.79 8-4V7M4 7c0 2.21 3.582 4 8 4s8-1.79 8-4M4 7c0-2.21 3.582-4 8-4s8 1.79 8-4m0 5c0 2.21-3.582 4-8 4s-8-1.79-8-4" />
              </svg>
            </div>
            <div>
              <h1 className="text-xl font-bold text-white tracking-tight">DBArchitect AI</h1>
              <p className="text-xs text-slate-500 font-medium uppercase tracking-widest">Full-Stack Architect</p>
            </div>
          </div>
          <div className="flex flex-col items-end">
             <span className={`text-[9px] font-bold px-2 py-0.5 rounded border uppercase tracking-tighter transition-all duration-700 ${environment === 'production' ? 'text-blue-400 bg-blue-500/10 border-blue-500/20 shadow-[0_0_10px_rgba(59,130,246,0.2)]' : 'text-amber-500 bg-amber-500/10 border-amber-500/20'}`}>
               {environment}
             </span>
          </div>
        </div>

        {/* Templates Section */}
        <div className="px-4 py-3 bg-slate-900/30 border-b border-slate-800">
          <h2 className="text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-3">Architectural Blueprints</h2>
          <div className="flex flex-wrap gap-2">
            {templates.map(t => (
              <button 
                key={t.name}
                onClick={() => {
                  setEnvironment('staging');
                  runPrompt(t.prompt);
                }}
                disabled={isLoading}
                className="text-[10px] font-semibold bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white px-3 py-1.5 rounded-full border border-slate-700 transition-all disabled:opacity-50"
              >
                {t.name}
              </button>
            ))}
          </div>
        </div>

        {/* Messages */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4 scrollbar-thin">
          {messages.map((msg, i) => (
            <div key={i} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
              <div className={`max-w-[90%] rounded-2xl p-4 text-sm leading-relaxed shadow-sm ${
                msg.role === 'user' 
                  ? 'bg-blue-600 text-white rounded-tr-none' 
                  : 'bg-slate-800 text-slate-300 border border-slate-700 rounded-tl-none'
              }`}>
                {msg.content}
                {msg.schema && (
                  <div className="flex flex-col gap-2 mt-3">
                    <button 
                      onClick={() => {
                        setCurrentSchema(msg.schema!);
                        if (msg.schema?.frontendCode) setView('frontend');
                      }}
                      className="block w-full text-center py-2 px-4 bg-slate-700 hover:bg-slate-600 rounded-lg text-xs font-semibold transition-all border border-slate-600"
                    >
                      View Architecture Blueprint
                    </button>
                    <div className="flex flex-wrap gap-2">
                      <button 
                        onClick={() => {
                          setCurrentSchema(msg.schema!);
                          setView('deploy');
                        }}
                        className="flex-1 text-center py-2 px-2 bg-amber-600/20 hover:bg-amber-600/30 text-amber-400 rounded-lg text-[10px] font-bold transition-all border border-amber-500/20 uppercase tracking-widest"
                      >
                        Infrastructure
                      </button>
                      <button 
                        onClick={() => {
                          setCurrentSchema(msg.schema!);
                          setView('security');
                        }}
                        className="flex-1 text-center py-2 px-2 bg-indigo-600/20 hover:bg-indigo-600/30 text-indigo-400 rounded-lg text-[10px] font-bold transition-all border border-indigo-500/20 uppercase tracking-widest"
                      >
                        Security
                      </button>
                      <button 
                        onClick={() => {
                          setCurrentSchema(msg.schema!);
                          setView('uat');
                        }}
                        className="flex-1 text-center py-2 px-2 bg-emerald-600/20 hover:bg-emerald-600/30 text-emerald-400 rounded-lg text-[10px] font-bold transition-all border border-emerald-500/20 uppercase tracking-widest"
                      >
                        UAT Lab
                      </button>
                      <button 
                        onClick={() => {
                          setCurrentSchema(msg.schema!);
                          setView('training');
                        }}
                        className="flex-1 text-center py-2 px-2 bg-blue-600/20 hover:bg-blue-600/30 text-blue-400 rounded-lg text-[10px] font-bold transition-all border border-blue-500/20 uppercase tracking-widest"
                      >
                        Training
                      </button>
                      <button 
                        onClick={() => {
                          setCurrentSchema(msg.schema!);
                          setView('monitoring');
                        }}
                        className="flex-1 text-center py-2 px-2 bg-pink-600/20 hover:bg-pink-600/30 text-pink-400 rounded-lg text-[10px] font-bold transition-all border border-pink-500/20 uppercase tracking-widest"
                      >
                        Monitoring
                      </button>
                    </div>
                  </div>
                )}
              </div>
            </div>
          ))}
          {isLoading && (
            <div className="flex justify-start">
              <div className="bg-slate-800 text-slate-400 p-4 rounded-2xl rounded-tl-none border border-slate-700 flex items-center gap-3 italic">
                <span className="flex gap-1">
                  <span className="w-1.5 h-1.5 bg-slate-500 rounded-full animate-bounce"></span>
                  <span className="w-1.5 h-1.5 bg-slate-500 rounded-full animate-bounce [animation-delay:0.2s]"></span>
                  <span className="w-1.5 h-1.5 bg-slate-500 rounded-full animate-bounce [animation-delay:0.4s]"></span>
                </span>
                Architecting System...
              </div>
            </div>
          )}
          <div ref={chatEndRef} />
        </div>

        {/* Input */}
        <form onSubmit={handleSubmit} className="p-4 bg-slate-900 border-t border-slate-800">
          <div className="relative">
            <textarea
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
              placeholder="e.g., Design a secure library system with JWT auth..."
              className="w-full bg-slate-800 border border-slate-700 rounded-xl py-3 px-4 pr-12 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500/50 resize-none min-h-[80px] scrollbar-none"
              onKeyDown={(e) => {
                if (e.key === 'Enter' && !e.shiftKey) {
                  e.preventDefault();
                  handleSubmit(e);
                }
              }}
            />
            <button
              type="submit"
              disabled={isLoading || !inputValue.trim()}
              className="absolute bottom-3 right-3 p-2 bg-blue-600 hover:bg-blue-500 disabled:opacity-50 rounded-lg transition-all shadow-lg"
            >
              <svg className="w-5 h-5 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 10l7-7m0 0l7 7m-7-7v18" />
              </svg>
            </button>
          </div>
        </form>
      </div>

      {/* Main Preview */}
      <div className="flex-1 flex flex-col p-6 bg-slate-950 relative">
        {isLoading && currentSchema && (
          <div className="absolute inset-0 z-50 bg-slate-950/40 backdrop-blur-sm flex items-center justify-center pointer-events-none transition-all">
            <div className="bg-slate-900 border border-slate-800 p-8 rounded-3xl shadow-2xl flex flex-col items-center gap-4 animate-pulse">
               <div className="w-12 h-12 border-4 border-blue-500 border-t-transparent rounded-full animate-spin"></div>
               <span className="text-xs font-bold text-slate-400 uppercase tracking-widest">Generating New Version</span>
            </div>
          </div>
        )}

        <div className="flex items-center justify-between mb-4">
          <div className="flex bg-slate-900 p-1 rounded-lg border border-slate-800 shadow-xl overflow-x-auto scrollbar-none">
            {(['diagram', 'sql', 'api', 'frontend', 'deploy', 'uat', 'training', 'monitoring', 'errors', 'security'] as const).map((v) => (
              <button 
                key={v}
                onClick={() => setView(v)}
                className={`flex items-center gap-2 px-4 py-2 rounded-md text-xs font-bold transition-all whitespace-nowrap ${view === v ? 'bg-slate-800 text-blue-400 shadow-inner' : 'text-slate-500 hover:text-slate-300'}`}
              >
                {v === 'uat' ? 'UAT LAB' : v === 'deploy' ? 'DEPLOYMENT' : v === 'training' ? 'DOCS & TRAINING' : v === 'errors' ? 'ERROR SPECS' : v.toUpperCase()}
              </button>
            ))}
          </div>
          <div className="text-[10px] text-slate-500 font-mono flex items-center gap-2 bg-slate-900/50 px-3 py-1 rounded-full border border-slate-800 shrink-0 ml-4">
            <span className={`w-2 h-2 rounded-full ${currentSchema ? 'bg-green-500 animate-pulse' : 'bg-slate-700'}`}></span>
            {currentSchema ? `V1.2.0 ${environment.toUpperCase()}` : 'AWAITING BLUEPRINT'}
          </div>
        </div>

        <div className="flex-1 min-h-0 relative">
          {currentSchema ? (
            <>
              {view === 'diagram' && <ERDiagram data={currentSchema} />}
              {view === 'sql' && <SqlEditor sql={currentSchema.sql} onCopy={handleCopy} />}
              {view === 'api' && <ApiPreview endpoints={currentSchema.apiEndpoints} code={currentSchema.implementationCode} onCopy={handleCopy} />}
              {view === 'frontend' && (
                <FrontendPreview 
                  code={currentSchema.frontendCode || '// No frontend code generated for this blueprint.'} 
                  title={getFrontendTitle()}
                  onCopy={handleCopy}
                />
              )}
              {view === 'deploy' && <DeploymentPreview environment={environment} onPromote={handlePromoteToProduction} />}
              {view === 'uat' && <UatLab data={currentSchema} onRefine={handleRefineWithFeedback} isRefining={isLoading} />}
              {view === 'training' && <TrainingLab data={currentSchema} />}
              {view === 'monitoring' && <MonitoringLab data={currentSchema} />}
              {view === 'errors' && <ErrorLab data={currentSchema} />}
              {view === 'security' && <SecurityLab data={currentSchema} />}
            </>
          ) : (
            <div className="h-full flex flex-col items-center justify-center text-slate-500 border-2 border-dashed border-slate-800 rounded-3xl bg-slate-900/20 backdrop-blur-sm">
              <div className="w-24 h-24 bg-slate-800/50 rounded-full flex items-center justify-center mb-6">
                <svg className="w-12 h-12 text-slate-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10" />
                </svg>
              </div>
              <p className="text-xl font-semibold text-slate-400 mb-2">No Architecture Blueprint Loaded</p>
              <p className="text-sm text-slate-600 max-w-sm text-center">Use the chat or select a template to generate a professional database schema, RESTful API, and React frontend with advanced security and monitoring.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default App;
