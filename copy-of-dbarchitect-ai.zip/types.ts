
export interface Field {
  name: string;
  type: string;
  isPrimary: boolean;
  isForeign: boolean;
  nullable: boolean;
  references?: string; // "table.column"
}

export interface DbIndex {
  name: string;
  columns: string[];
  type: 'btree' | 'fulltext' | 'unique' | 'hash';
}

export interface Entity {
  name: string;
  fields: Field[];
  indexes?: DbIndex[];
}

export interface Relationship {
  fromTable: string;
  fromField: string;
  toTable: string;
  toField: string;
  type: 'one-to-one' | 'one-to-many' | 'many-to-many';
}

export interface ApiEndpoint {
  method: 'GET' | 'POST' | 'PUT' | 'DELETE' | 'PATCH';
  path: string;
  description: string;
  summary: string;
  requestSchema?: string; // JSON string representation
  responseSchema?: string; // JSON string representation
  errorCodes?: string[]; // References to global error codes
  rolesRequired?: string[]; // RBAC requirements
}

export interface ManualSection {
  title: string;
  content: string;
  audience: 'Developer' | 'Admin' | 'End-User';
}

export interface MonitoringMetric {
  name: string;
  target: string;
  threshold: string;
}

export interface ErrorDefinition {
  code: string;
  httpStatus: number;
  message: string;
  description: string;
  mitigation: string;
}

export interface SecurityControl {
  name: string;
  type: 'AuthN' | 'AuthZ' | 'Encryption' | 'Network' | 'Audit';
  description: string;
  implementation: string;
}

export interface SchemaData {
  sql: string;
  apiEndpoints: ApiEndpoint[];
  implementationCode: string;
  frontendCode?: string;
  entities: Entity[];
  relationships: Relationship[];
  explanation: string;
  manual?: ManualSection[];
  monitoring?: {
    strategy: string;
    metrics: MonitoringMetric[];
    healthChecks: string[];
  };
  errorHandling?: {
    strategy: string;
    standardResponse: string;
    errorCodes: ErrorDefinition[];
  };
  security?: {
    strategy: string;
    authentication: string; // JWT, OAuth2, etc.
    authorization: string; // RBAC, ABAC
    controls: SecurityControl[];
    encryptionStrategy: string;
  };
}

export interface ChatMessage {
  role: 'user' | 'assistant';
  content: string;
  schema?: SchemaData;
}
