
import React, { useState } from 'react';
import { ApiEndpoint } from '../types';

interface ApiPreviewProps {
  endpoints: ApiEndpoint[];
  code: string;
  onCopy?: () => void;
}

const ApiPreview: React.FC<ApiPreviewProps> = ({ endpoints, code, onCopy }) => {
  const [selectedEndpointIndex, setSelectedEndpointIndex] = useState<number | null>(0);
  const [viewMode, setViewMode] = useState<'code' | 'docs'>('docs');

  const getMethodColor = (method: string) => {
    switch (method) {
      case 'GET': return 'text-blue-400 bg-blue-400/10';
      case 'POST': return 'text-green-400 bg-green-400/10';
      case 'PUT': return 'text-amber-400 bg-amber-400/10';
      case 'DELETE': return 'text-red-400 bg-red-400/10';
      default: return 'text-slate-400 bg-slate-400/10';
    }
  };

  const highlightCode = (js: string) => {
    const keywords = /\b(const|let|var|async|await|function|export|import|from|return|if|else|try|catch|new|class|extends|await|next)\b/g;
    const methods = /\.(get|post|put|delete|patch|status|json|send|query|params|body|headers|use|bcrypt|jwt|sign|verify|hash|compare)\b/g;
    const strings = /(['"`].*?['"`])/g;
    const comments = /(\/\/.*$|\/\*[\s\S]*?\*\/)/gm;
    
    return js
      .replace(comments, match => `<span class="text-slate-500 italic">${match}</span>`)
      .replace(keywords, match => `<span class="text-pink-400 font-medium">${match}</span>`)
      .replace(methods, match => `<span class="text-blue-300">${match}</span>`)
      .replace(strings, match => `<span class="text-emerald-300">${match}</span>`);
  };

  const selectedEndpoint = selectedEndpointIndex !== null ? endpoints[selectedEndpointIndex] : null;

  return (
    <div className="flex h-full gap-4">
      {/* Sidebar: Endpoint List */}
      <div className="w-80 flex flex-col bg-slate-900 rounded-xl border border-slate-800 overflow-hidden shadow-xl shrink-0">
        <div className="px-4 py-3 border-b border-slate-800 bg-slate-900/50 flex justify-between items-center">
          <span className="text-[10px] font-mono text-slate-500 uppercase tracking-widest">REST Endpoints</span>
          <span className="text-[10px] text-slate-600 font-mono">{endpoints.length} Routes</span>
        </div>
        <div className="flex-1 overflow-y-auto divide-y divide-slate-800/50 scrollbar-thin">
          {endpoints.map((ep, i) => (
            <button 
              key={i} 
              onClick={() => setSelectedEndpointIndex(i)}
              className={`w-full p-3 flex items-start gap-3 text-left transition-all ${
                selectedEndpointIndex === i ? 'bg-blue-600/10 border-l-2 border-blue-500' : 'hover:bg-slate-800/30 border-l-2 border-transparent'
              }`}
            >
              <span className={`px-1.5 py-0.5 rounded text-[9px] font-bold min-w-[45px] text-center ${getMethodColor(ep.method)}`}>
                {ep.method}
              </span>
              <div className="flex-1 min-w-0">
                <div className="text-[11px] font-mono text-slate-200 truncate">{ep.path}</div>
                <div className="text-[10px] text-slate-500 mt-0.5 truncate">{ep.summary}</div>
              </div>
            </button>
          ))}
        </div>
        <div className="p-2 bg-slate-900 border-t border-slate-800">
          <div className="flex gap-1">
            <button 
              onClick={() => setViewMode('docs')}
              className={`flex-1 py-1.5 rounded text-[10px] font-bold uppercase tracking-widest transition-all ${viewMode === 'docs' ? 'bg-slate-700 text-white' : 'text-slate-500 hover:text-slate-300'}`}
            >
              Docs
            </button>
            <button 
              onClick={() => setViewMode('code')}
              className={`flex-1 py-1.5 rounded text-[10px] font-bold uppercase tracking-widest transition-all ${viewMode === 'code' ? 'bg-slate-700 text-white' : 'text-slate-500 hover:text-slate-300'}`}
            >
              Code
            </button>
          </div>
        </div>
      </div>

      {/* Main Panel: Documentation or Code */}
      <div className="flex-1 flex flex-col min-w-0">
        {viewMode === 'docs' && selectedEndpoint ? (
          <div className="flex-1 bg-slate-950 rounded-xl border border-slate-800 overflow-hidden flex flex-col shadow-2xl">
            <div className="px-6 py-4 bg-slate-900 border-b border-slate-800 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <span className={`px-2 py-1 rounded text-xs font-black ${getMethodColor(selectedEndpoint.method)}`}>
                  {selectedEndpoint.method}
                </span>
                <h2 className="text-sm font-mono text-white font-bold">{selectedEndpoint.path}</h2>
              </div>
              <div className="text-[10px] text-slate-500 font-mono">v1.0.0</div>
            </div>
            
            <div className="flex-1 overflow-y-auto p-8 scrollbar-thin">
              <div className="max-w-3xl space-y-8">
                <section>
                  <h3 className="text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-2">Summary</h3>
                  <p className="text-sm text-slate-200">{selectedEndpoint.summary}</p>
                </section>

                <section>
                  <h3 className="text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-2">Description</h3>
                  <p className="text-sm text-slate-400 leading-relaxed">{selectedEndpoint.description}</p>
                </section>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <section>
                    <h3 className="text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-3 flex items-center gap-2">
                      <svg className="w-3 h-3 text-blue-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 13l-3 3m0 0l-3-3m3 3V8m0 13a9 9 0 110-18 9 9 0 010 18z" />
                      </svg>
                      Request Schema
                    </h3>
                    <div className="bg-slate-900 rounded-lg p-4 font-mono text-[11px] border border-slate-800">
                      <pre className="text-emerald-400 overflow-x-auto">
                        {selectedEndpoint.requestSchema || '// No request body required'}
                      </pre>
                    </div>
                  </section>

                  <section>
                    <h3 className="text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-3 flex items-center gap-2">
                      <svg className="w-3 h-3 text-emerald-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 11l3-3m0 0l3 3m-3-3v8m0-13a9 9 0 110 18 9 9 0 010 18z" />
                      </svg>
                      Response Schema
                    </h3>
                    <div className="bg-slate-900 rounded-lg p-4 font-mono text-[11px] border border-slate-800">
                      <pre className="text-blue-300 overflow-x-auto">
                        {selectedEndpoint.responseSchema || '{}'}
                      </pre>
                    </div>
                  </section>
                </div>
              </div>
            </div>
          </div>
        ) : (
          <div className="flex-1 relative bg-slate-950 rounded-xl border border-slate-800 overflow-hidden flex flex-col shadow-2xl">
            <div className="flex items-center justify-between px-4 py-2 bg-slate-900 border-b border-slate-800">
              <div className="flex items-center gap-2">
                <div className="flex gap-1.5 mr-3">
                  <div className="w-2.5 h-2.5 rounded-full bg-red-500/50"></div>
                  <div className="w-2.5 h-2.5 rounded-full bg-amber-500/50"></div>
                  <div className="w-2.5 h-2.5 rounded-full bg-green-500/50"></div>
                </div>
                <span className="text-xs font-mono text-slate-400 uppercase tracking-widest">api-controller.js</span>
              </div>
              <button 
                onClick={() => {
                  navigator.clipboard.writeText(code);
                  if (onCopy) onCopy();
                }}
                className="text-xs bg-slate-800 hover:bg-slate-700 text-slate-300 px-3 py-1 rounded transition-colors flex items-center gap-2"
              >
                <svg className="w-3 h-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 5H6a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2v-1M8 5a2 2 0 002 2h2a2 2 0 002-2M8 5a2 2 0 012-2h2a2 2 0 012 2m0 0h2a2 2 0 012 2v3m2 4H10m0 0l3-3m-3 3l3 3" />
                </svg>
                Copy Implementation
              </button>
            </div>
            <pre className="flex-1 p-6 overflow-auto font-mono text-sm leading-relaxed scrollbar-thin">
              <code dangerouslySetInnerHTML={{ __html: highlightCode(code) }} />
            </pre>
          </div>
        )}
      </div>
    </div>
  );
};

export default ApiPreview;
