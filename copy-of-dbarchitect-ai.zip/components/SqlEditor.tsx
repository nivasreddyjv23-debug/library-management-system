
import React from 'react';

interface SqlEditorProps {
  sql: string;
  onCopy?: () => void;
}

const SqlEditor: React.FC<SqlEditorProps> = ({ sql, onCopy }) => {
  const highlightSql = (code: string) => {
    const keywords = /\b(CREATE|TABLE|PRIMARY|KEY|FOREIGN|REFERENCES|NOT|NULL|INT|VARCHAR|TEXT|TIMESTAMP|SERIAL|INSERT|INTO|VALUES|DATE|BOOLEAN|INDEX|UNIQUE|FULLTEXT|GIN|GIST|ON|USING|HASH|BTREE|PARTITION|BY|MATERIALIZED|VIEW|REFRESH|CONCURRENTLY|EXPLAIN|ANALYZE)\b/gi;
    const types = /\b(INT|VARCHAR|TEXT|TIMESTAMP|SERIAL|BOOLEAN|DATE|JSONB|UUID|VECTOR|TSVECTOR|BYTEA)\b/gi;
    
    return code
      .replace(keywords, match => `<span class="text-blue-400 font-bold">${match.toUpperCase()}</span>`)
      .replace(types, match => `<span class="text-emerald-400">${match.toUpperCase()}</span>`)
      .replace(/'(.*?)'/g, match => `<span class="text-orange-300">${match}</span>`)
      .replace(/--.*$/gm, match => `<span class="text-slate-500 italic">${match}</span>`);
  };

  const copyToClipboard = () => {
    navigator.clipboard.writeText(sql);
    if (onCopy) onCopy();
  };

  return (
    <div className="relative h-full bg-slate-950 rounded-xl border border-slate-800 overflow-hidden flex flex-col">
      <div className="flex items-center justify-between px-4 py-2 bg-slate-900 border-b border-slate-800">
        <span className="text-xs font-mono text-slate-400 uppercase tracking-widest">DDL Output (PostgreSQL + Caching Opt)</span>
        <button 
          onClick={copyToClipboard}
          className="text-xs bg-slate-800 hover:bg-slate-700 text-slate-300 px-3 py-1 rounded transition-colors flex items-center gap-2"
        >
          <svg className="w-3 h-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 5H6a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2v-1M8 5a2 2 0 002 2h2a2 2 0 002-2M8 5a2 2 0 012-2h2a2 2 0 012 2m0 0h2a2 2 0 012 2v3m2 4H10m0 0l3-3m-3 3l3 3" />
          </svg>
          Copy Code
        </button>
      </div>
      <pre className="flex-1 p-6 overflow-auto font-mono text-sm leading-relaxed scrollbar-thin">
        <code 
          dangerouslySetInnerHTML={{ __html: highlightSql(sql) }} 
        />
      </pre>
    </div>
  );
};

export default SqlEditor;
