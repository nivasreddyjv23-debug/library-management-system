
import React, { useState, useEffect, useMemo } from 'react';
import { SchemaData } from '../types';

interface MonitoringLabProps {
  data: SchemaData;
}

const MonitoringLab: React.FC<MonitoringLabProps> = ({ data }) => {
  const [logs, setLogs] = useState<{ id: string; time: string; level: string; msg: string; source: string }[]>([]);
  const [metrics, setMetrics] = useState<{ latency: number[]; throughput: number[]; errors: number[] }>({
    latency: Array(20).fill(0).map(() => Math.floor(Math.random() * 100) + 20),
    throughput: Array(20).fill(0).map(() => Math.floor(Math.random() * 50) + 10),
    errors: Array(20).fill(0).map(() => Math.random() > 0.9 ? 1 : 0),
  });

  // Simulated live log updates
  useEffect(() => {
    const logPool = [
      { level: 'INFO', msg: 'GET /api/v1/books - 200 OK', source: 'api-gateway' },
      { level: 'INFO', msg: 'Cache hit for query: "The Great Gatsby"', source: 'redis-node' },
      { level: 'DEBUG', msg: 'Materialized view REFRESH started', source: 'postgres-worker' },
      { level: 'WARN', msg: 'Slow query detected on "members" table', source: 'db-monitor' },
      { level: 'INFO', msg: 'New loan transaction committed: #4928', source: 'loan-service' },
      { level: 'ERROR', msg: 'Failed to process return: Missing record ID', source: 'api-gateway' },
    ];

    const interval = setInterval(() => {
      const entry = logPool[Math.floor(Math.random() * logPool.length)];
      const newLog = {
        id: Math.random().toString(36).substr(2, 9),
        time: new Date().toLocaleTimeString(),
        ...entry
      };
      setLogs(prev => [newLog, ...prev].slice(0, 50));
      
      // Randomly update metrics
      setMetrics(prev => ({
        latency: [...prev.latency.slice(1), Math.floor(Math.random() * 80) + 20],
        throughput: [...prev.throughput.slice(1), Math.floor(Math.random() * 60) + 5],
        errors: [...prev.errors.slice(1), Math.random() > 0.95 ? 1 : 0],
      }));
    }, 2000);

    return () => clearInterval(interval);
  }, []);

  const healthScore = useMemo(() => {
    const errorCount = metrics.errors.filter(e => e > 0).length;
    return Math.max(0, 100 - (errorCount * 10));
  }, [metrics.errors]);

  return (
    <div className="flex flex-col h-full gap-4 bg-slate-950 p-4 rounded-xl border border-slate-800 overflow-hidden font-mono">
      {/* Header Metrics */}
      <div className="grid grid-cols-4 gap-4">
        <div className="bg-slate-900/50 border border-slate-800 p-4 rounded-xl">
          <div className="text-[10px] text-slate-500 uppercase font-black mb-1">System Health</div>
          <div className="flex items-end gap-2">
            <div className={`text-2xl font-bold ${healthScore > 90 ? 'text-emerald-500' : 'text-amber-500'}`}>{healthScore}%</div>
            <div className="text-[10px] text-slate-600 mb-1">Global Cluster</div>
          </div>
          <div className="w-full h-1 bg-slate-800 rounded-full mt-2 overflow-hidden">
            <div className={`h-full transition-all duration-1000 ${healthScore > 90 ? 'bg-emerald-500' : 'bg-amber-500'}`} style={{ width: `${healthScore}%` }}></div>
          </div>
        </div>
        <div className="bg-slate-900/50 border border-slate-800 p-4 rounded-xl">
          <div className="text-[10px] text-slate-500 uppercase font-black mb-1">Avg Latency</div>
          <div className="flex items-end gap-2">
            <div className="text-2xl font-bold text-blue-400">{metrics.latency[metrics.latency.length - 1]}ms</div>
            <div className="text-[10px] text-slate-600 mb-1">p95 Baseline</div>
          </div>
        </div>
        <div className="bg-slate-900/50 border border-slate-800 p-4 rounded-xl">
          <div className="text-[10px] text-slate-500 uppercase font-black mb-1">Throughput</div>
          <div className="flex items-end gap-2">
            <div className="text-2xl font-bold text-indigo-400">{metrics.throughput[metrics.throughput.length - 1]} rps</div>
            <div className="text-[10px] text-slate-600 mb-1">Active Load</div>
          </div>
        </div>
        <div className="bg-slate-900/50 border border-slate-800 p-4 rounded-xl">
          <div className="text-[10px] text-slate-500 uppercase font-black mb-1">Active Logs</div>
          <div className="flex items-end gap-2">
            <div className="text-2xl font-bold text-slate-300">{logs.length}</div>
            <div className="text-[10px] text-slate-600 mb-1">Live Buffer</div>
          </div>
        </div>
      </div>

      <div className="flex-1 flex gap-4 min-h-0">
        {/* Visual Charts (Simulated with Bars) */}
        <div className="flex-[2] flex flex-col gap-4">
          <div className="bg-slate-900 rounded-xl border border-slate-800 flex flex-col p-4 h-1/2 overflow-hidden">
             <div className="flex justify-between items-center mb-4">
                <span className="text-xs font-bold text-slate-400 uppercase tracking-widest">Performance Metrics (Real-time)</span>
                <div className="flex gap-4">
                  <div className="flex items-center gap-1.5"><span className="w-2 h-2 bg-blue-500 rounded-full"></span><span className="text-[9px] text-slate-600">Latency</span></div>
                  <div className="flex items-center gap-1.5"><span className="w-2 h-2 bg-indigo-500 rounded-full"></span><span className="text-[9px] text-slate-600">Load</span></div>
                </div>
             </div>
             <div className="flex-1 flex items-end gap-1 px-2">
                {metrics.latency.map((v, i) => (
                  <div key={i} className="flex-1 flex flex-col justify-end gap-0.5 group">
                    <div className="w-full bg-blue-500/30 hover:bg-blue-500 transition-all rounded-t-sm" style={{ height: `${(v / 150) * 100}%` }}></div>
                    <div className="w-full bg-indigo-500/30 rounded-t-sm" style={{ height: `${(metrics.throughput[i] / 80) * 100}%` }}></div>
                  </div>
                ))}
             </div>
          </div>

          <div className="bg-slate-900 rounded-xl border border-slate-800 p-4 h-1/2 flex flex-col overflow-hidden">
             <div className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-4">Monitoring Strategy & KPIs</div>
             <div className="flex-1 overflow-y-auto space-y-4 pr-2 scrollbar-thin">
                <div className="bg-slate-950 p-3 rounded-lg border border-slate-800">
                   <div className="text-[10px] text-blue-500 font-bold uppercase mb-2">Strategy Overview</div>
                   <p className="text-[11px] text-slate-400 leading-relaxed italic">"{data.monitoring?.strategy}"</p>
                </div>
                <div className="grid grid-cols-2 gap-3">
                   {data.monitoring?.metrics.map((m, i) => (
                     <div key={i} className="bg-slate-950 p-2 rounded-lg border border-slate-800 flex justify-between items-center">
                        <div className="min-w-0">
                           <div className="text-[10px] text-slate-300 font-bold truncate">{m.name}</div>
                           <div className="text-[9px] text-slate-600">{m.target}</div>
                        </div>
                        <div className="text-[9px] font-mono text-emerald-500 bg-emerald-500/10 px-1.5 py-0.5 rounded border border-emerald-500/20">{m.threshold}</div>
                     </div>
                   ))}
                </div>
                <div className="flex flex-wrap gap-2">
                   {data.monitoring?.healthChecks.map((hc, i) => (
                     <span key={i} className="text-[9px] bg-slate-800 text-slate-400 px-2 py-1 rounded border border-slate-700">HTTP {hc}</span>
                   ))}
                </div>
             </div>
          </div>
        </div>

        {/* Live Log Stream */}
        <div className="flex-1 bg-slate-900 rounded-xl border border-slate-800 flex flex-col overflow-hidden">
          <div className="px-4 py-3 bg-slate-900/50 border-b border-slate-800 flex items-center justify-between">
            <span className="text-xs font-bold text-white uppercase tracking-widest">Log Stream</span>
            <span className="text-[9px] text-slate-600 animate-pulse font-bold">● LIVE TAIL</span>
          </div>
          <div className="flex-1 overflow-y-auto p-4 space-y-2 scrollbar-thin bg-slate-950/50">
            {logs.map(log => (
              <div key={log.id} className="text-[10px] leading-relaxed border-b border-slate-800/50 pb-2 animate-in slide-in-from-right-2">
                <div className="flex justify-between items-center mb-1">
                  <span className="text-slate-600 font-mono">[{log.time}]</span>
                  <span className={`px-1 rounded font-bold text-[9px] ${
                    log.level === 'ERROR' ? 'bg-red-500/20 text-red-500' :
                    log.level === 'WARN' ? 'bg-amber-500/20 text-amber-500' :
                    'bg-slate-800 text-slate-400'
                  }`}>{log.level}</span>
                </div>
                <div className="flex items-start gap-2">
                   <span className="text-blue-500 text-[9px] shrink-0">{log.source}</span>
                   <span className="text-slate-300 break-all">{log.msg}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default MonitoringLab;
