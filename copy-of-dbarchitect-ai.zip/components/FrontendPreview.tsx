
import React from 'react';

interface FrontendPreviewProps {
  code: string;
  title?: string;
  onCopy?: () => void;
}

const FrontendPreview: React.FC<FrontendPreviewProps> = ({ code, title = "GeneratedComponent.tsx", onCopy }) => {
  const highlightCode = (js: string) => {
    const keywords = /\b(const|let|var|async|await|function|export|import|from|return|if|else|try|catch|new|class|extends|await|next|interface|type)\b/g;
    const jsx = /(<[A-Za-z0-9]+|[\/]>)/g;
    const strings = /(['"`].*?['"`])/g;
    const tailwind = /className=(['"`].*?['"`])/g;
    
    return js
      .replace(strings, match => `<span class="text-emerald-300">${match}</span>`)
      .replace(tailwind, match => `<span class="text-amber-200">${match}</span>`)
      .replace(keywords, match => `<span class="text-pink-400 font-medium">${match}</span>`)
      .replace(jsx, match => `<span class="text-blue-300">${match}</span>`);
  };

  return (
    <div className="flex flex-col h-full bg-slate-950 rounded-xl border border-slate-800 overflow-hidden shadow-2xl">
      <div className="flex items-center justify-between px-4 py-2 bg-slate-900 border-b border-slate-800">
        <div className="flex items-center gap-2">
          <div className="flex gap-1.5 mr-3">
            <div className="w-2.5 h-2.5 rounded-full bg-red-500/50"></div>
            <div className="w-2.5 h-2.5 rounded-full bg-amber-500/50"></div>
            <div className="w-2.5 h-2.5 rounded-full bg-green-500/50"></div>
          </div>
          <span className="text-xs font-mono text-slate-400 uppercase tracking-widest">{title} (React + Tailwind)</span>
        </div>
        <button 
          onClick={() => {
            navigator.clipboard.writeText(code);
            if (onCopy) onCopy();
          }}
          className="text-xs bg-slate-800 hover:bg-slate-700 text-slate-300 px-3 py-1 rounded transition-colors flex items-center gap-2"
        >
          <svg className="w-3 h-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 5H6a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2v-1M8 5a2 2 0 002 2h2a2 2 0 002-2M8 5a2 2 0 012-2h2a2 2 0 012 2m0 0h2a2 2 0 012 2v3m2 4H10m0 0l3-3m-3 3l3 3" />
          </svg>
          Copy Code
        </button>
      </div>
      <pre className="flex-1 p-6 overflow-auto font-mono text-sm leading-relaxed scrollbar-thin">
        <code dangerouslySetInnerHTML={{ __html: highlightCode(code) }} />
      </pre>
    </div>
  );
};

export default FrontendPreview;
