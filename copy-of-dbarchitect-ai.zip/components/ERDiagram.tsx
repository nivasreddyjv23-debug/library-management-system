
import React, { useEffect, useRef } from 'react';
import * as d3 from 'd3';
import { SchemaData, Entity, Relationship } from '../types';

interface ERDiagramProps {
  data: SchemaData;
}

const ERDiagram: React.FC<ERDiagramProps> = ({ data }) => {
  const svgRef = useRef<SVGSVGElement>(null);

  useEffect(() => {
    if (!svgRef.current || !data) return;

    const svg = d3.select(svgRef.current);
    svg.selectAll("*").remove();

    const width = 1000;
    const height = 800;
    const nodeWidth = 200;
    const fieldHeight = 22;
    const headerHeight = 30;
    const indexHeaderHeight = 20;

    // Zoom setup
    const g = svg.append("g");
    const zoom = d3.zoom<SVGSVGElement, unknown>()
      .scaleExtent([0.1, 4])
      .on("zoom", (event) => g.attr("transform", event.transform));
    
    svg.call(zoom);

    // Prepare links (relationships)
    const links = data.relationships.map((r, i) => ({
      id: i,
      source: r.fromTable,
      target: r.toTable,
      type: r.type
    }));

    // Prepare nodes (entities)
    const nodes = data.entities.map(e => ({
      id: e.name,
      entity: e,
      x: Math.random() * width,
      y: Math.random() * height
    }));

    const simulation = d3.forceSimulation<any>(nodes)
      .force("link", d3.forceLink<any, any>(links).id(d => d.id).distance(300))
      .force("charge", d3.forceManyBody().strength(-3000))
      .force("center", d3.forceCenter(width / 2, height / 2))
      .force("collision", d3.forceCollide().radius(nodeWidth));

    // Define marker for arrowheads
    svg.append("defs").append("marker")
      .attr("id", "arrowhead")
      .attr("viewBox", "0 -5 10 10")
      .attr("refX", 10)
      .attr("refY", 0)
      .attr("orient", "auto")
      .attr("markerWidth", 6)
      .attr("markerHeight", 6)
      .attr("xoverflow", "visible")
      .append("svg:path")
      .attr("d", "M 0,-5 L 10 ,0 L 0,5")
      .attr("fill", "#64748b")
      .style("stroke", "none");

    // Drawing links
    const link = g.append("g")
      .selectAll("line")
      .data(links)
      .join("line")
      .attr("stroke", "#475569")
      .attr("stroke-width", 2)
      .attr("marker-end", "url(#arrowhead)");

    // Drawing table nodes
    const node = g.append("g")
      .selectAll("g")
      .data(nodes)
      .join("g")
      .call(d3.drag<any, any>()
        .on("start", (event, d) => {
          if (!event.active) simulation.alphaTarget(0.3).restart();
          d.fx = d.x;
          d.fy = d.y;
        })
        .on("drag", (event, d) => {
          d.fx = event.x;
          d.fy = event.y;
        })
        .on("end", (event, d) => {
          if (!event.active) simulation.alphaTarget(0);
          d.fx = null;
          d.fy = null;
        }));

    const getTableHeight = (entity: Entity) => {
      const fieldsLen = entity.fields.length;
      const indexesLen = (entity.indexes?.length || 0);
      const indexSection = indexesLen > 0 ? indexHeaderHeight + (indexesLen * fieldHeight) : 0;
      return headerHeight + (fieldsLen * fieldHeight) + indexSection + 10;
    };

    // Table container
    node.append("rect")
      .attr("width", nodeWidth)
      .attr("height", d => getTableHeight(d.entity))
      .attr("fill", "#1e293b")
      .attr("stroke", "#3b82f6")
      .attr("stroke-width", 2)
      .attr("rx", 6);

    // Table Header
    node.append("rect")
      .attr("width", nodeWidth)
      .attr("height", headerHeight)
      .attr("fill", "#3b82f6")
      .attr("rx", 6);

    node.append("text")
      .attr("x", nodeWidth / 2)
      .attr("y", 20)
      .attr("text-anchor", "middle")
      .attr("fill", "white")
      .attr("font-weight", "bold")
      .attr("font-size", "14px")
      .text(d => d.entity.name);

    // Fields
    const fieldGroups = node.selectAll(".field")
      .data(d => d.entity.fields)
      .enter()
      .append("g")
      .attr("transform", (d, i) => `translate(0, ${headerHeight + i * fieldHeight})`);

    fieldGroups.append("text")
      .attr("x", 10)
      .attr("y", 16)
      .attr("fill", d => d.isPrimary ? "#fbbf24" : d.isForeign ? "#60a5fa" : "#cbd5e1")
      .attr("font-size", "11px")
      .text(d => `${d.isPrimary ? '🔑 ' : d.isForeign ? '🔗 ' : '○ '}${d.name}: ${d.type}`);

    // Indexes Section
    const indexContainer = node.append("g")
      .attr("transform", d => `translate(0, ${headerHeight + d.entity.fields.length * fieldHeight + 5})`)
      .style("display", d => (d.entity.indexes?.length || 0) > 0 ? "block" : "none");

    indexContainer.append("line")
      .attr("x1", 10)
      .attr("x2", nodeWidth - 10)
      .attr("y1", 0)
      .attr("y2", 0)
      .attr("stroke", "#334155")
      .attr("stroke-width", 1);

    indexContainer.append("text")
      .attr("x", 10)
      .attr("y", 12)
      .attr("fill", "#94a3b8")
      .attr("font-size", "9px")
      .attr("font-weight", "bold")
      .text("INDEXES");

    const indexRows = indexContainer.selectAll(".index-row")
      .data(d => d.entity.indexes || [])
      .enter()
      .append("g")
      .attr("transform", (d, i) => `translate(0, ${indexHeaderHeight + i * fieldHeight})`);

    indexRows.append("text")
      .attr("x", 10)
      .attr("y", 12)
      .attr("fill", d => d.type === 'fulltext' ? '#ec4899' : '#10b981')
      .attr("font-size", "10px")
      .text(d => `⚡ ${d.type.toUpperCase()}: ${d.columns.join(', ')}`);

    simulation.on("tick", () => {
      link
        .attr("x1", d => {
          const source = typeof d.source === 'string' ? nodes.find(n => n.id === d.source) : d.source;
          return (source?.x || 0) + nodeWidth / 2;
        })
        .attr("y1", d => {
          const source = typeof d.source === 'string' ? nodes.find(n => n.id === d.source) : d.source;
          const h = getTableHeight(source?.entity);
          return (source?.y || 0) + h / 2;
        })
        .attr("x2", d => {
          const target = typeof d.target === 'string' ? nodes.find(n => n.id === d.target) : d.target;
          return (target?.x || 0) + nodeWidth / 2;
        })
        .attr("y2", d => {
          const target = typeof d.target === 'string' ? nodes.find(n => n.id === d.target) : d.target;
          const h = getTableHeight(target?.entity);
          return (target?.y || 0) + h / 2;
        });

      node.attr("transform", d => `translate(${d.x}, ${d.y})`);
    });

  }, [data]);

  return (
    <div className="w-full h-full relative overflow-hidden bg-slate-900 rounded-xl border border-slate-800">
      <div className="absolute top-4 right-4 flex flex-col gap-2 z-10">
         <span className="flex items-center gap-2 text-[10px] bg-slate-800/80 backdrop-blur px-2 py-1 rounded text-amber-400">
            <span className="w-2 h-2 rounded-full bg-amber-400"></span> Primary Key
         </span>
         <span className="flex items-center gap-2 text-[10px] bg-slate-800/80 backdrop-blur px-2 py-1 rounded text-blue-400">
            <span className="w-2 h-2 rounded-full bg-blue-400"></span> Foreign Key
         </span>
         <span className="flex items-center gap-2 text-[10px] bg-slate-800/80 backdrop-blur px-2 py-1 rounded text-emerald-400">
            <span className="w-2 h-2 rounded-full bg-emerald-400"></span> B-Tree Index
         </span>
         <span className="flex items-center gap-2 text-[10px] bg-slate-800/80 backdrop-blur px-2 py-1 rounded text-pink-400">
            <span className="w-2 h-2 rounded-full bg-pink-400"></span> Full-Text Search
         </span>
      </div>
      <svg ref={svgRef} className="w-full h-full cursor-grab active:cursor-grabbing" />
    </div>
  );
};

export default ERDiagram;
