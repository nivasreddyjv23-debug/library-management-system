
import React from 'react';
import { SchemaData } from '../types';

interface ErrorLabProps {
  data: SchemaData;
}

const ErrorLab: React.FC<ErrorLabProps> = ({ data }) => {
  const errorHandling = data.errorHandling;

  if (!errorHandling) {
    return (
      <div className="h-full flex items-center justify-center text-slate-500 italic border border-slate-800 rounded-xl bg-slate-900/20">
        No error handling specifications found in this blueprint.
      </div>
    );
  }

  return (
    <div className="flex flex-col h-full gap-6 bg-slate-950 p-6 rounded-xl border border-slate-800 overflow-hidden shadow-2xl overflow-y-auto scrollbar-thin">
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Strategy Summary */}
        <div className="lg:col-span-2 space-y-6">
          <div className="bg-slate-900 border border-slate-800 p-6 rounded-2xl shadow-lg">
            <h2 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
              <svg className="w-5 h-5 text-amber-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
              </svg>
              Global Error Handling Strategy
            </h2>
            <p className="text-sm text-slate-400 leading-relaxed mb-6 italic">
              {errorHandling.strategy}
            </p>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
               <div className="bg-slate-950 p-3 rounded-lg border border-slate-800 text-center">
                  <div className="text-[10px] text-slate-500 uppercase font-bold mb-1">Total Codes</div>
                  <div className="text-xl font-bold text-blue-400 font-mono">{errorHandling.errorCodes.length}</div>
               </div>
               <div className="bg-slate-950 p-3 rounded-lg border border-slate-800 text-center">
                  <div className="text-[10px] text-slate-500 uppercase font-bold mb-1">Standardized</div>
                  <div className="text-xl font-bold text-emerald-400 font-mono">YES</div>
               </div>
               <div className="bg-slate-950 p-3 rounded-lg border border-slate-800 text-center">
                  <div className="text-[10px] text-slate-500 uppercase font-bold mb-1">Logging</div>
                  <div className="text-xl font-bold text-indigo-400 font-mono">ACTIVE</div>
               </div>
               <div className="bg-slate-950 p-3 rounded-lg border border-slate-800 text-center">
                  <div className="text-[10px] text-slate-500 uppercase font-bold mb-1">Audience</div>
                  <div className="text-xl font-bold text-slate-300 font-mono">DEV/API</div>
               </div>
            </div>
          </div>

          <div className="bg-slate-900 border border-slate-800 p-6 rounded-2xl shadow-lg">
             <h3 className="text-xs font-bold text-slate-500 uppercase tracking-widest mb-4">Centralized Error Registry</h3>
             <div className="overflow-x-auto">
                <table className="w-full text-left text-[11px] border-collapse">
                   <thead>
                      <tr className="border-b border-slate-800 text-slate-400 font-mono">
                         <th className="py-2 px-3 font-bold">CODE</th>
                         <th className="py-2 px-3 font-bold">STATUS</th>
                         <th className="py-2 px-3 font-bold">MESSAGE</th>
                         <th className="py-2 px-3 font-bold">MITIGATION</th>
                      </tr>
                   </thead>
                   <tbody className="divide-y divide-slate-800/50">
                      {errorHandling.errorCodes.map((err, i) => (
                        <tr key={i} className="hover:bg-slate-800/20 transition-colors">
                           <td className="py-3 px-3 font-mono text-amber-400 font-bold">{err.code}</td>
                           <td className="py-3 px-3">
                              <span className={`px-1.5 py-0.5 rounded-md font-bold ${
                                err.httpStatus >= 500 ? 'bg-red-500/20 text-red-400' :
                                err.httpStatus >= 400 ? 'bg-orange-500/20 text-orange-400' :
                                'bg-slate-800 text-slate-400'
                              }`}>{err.httpStatus}</span>
                           </td>
                           <td className="py-3 px-3 text-slate-200">
                              <div className="font-bold">{err.message}</div>
                              <div className="text-[9px] text-slate-500 mt-1 max-w-xs">{err.description}</div>
                           </td>
                           <td className="py-3 px-3 text-slate-400 max-w-xs italic">{err.mitigation}</td>
                        </tr>
                      ))}
                   </tbody>
                </table>
             </div>
          </div>
        </div>

        {/* Sidebar: Response Format & Best Practices */}
        <div className="space-y-6">
          <div className="bg-slate-900 border border-slate-800 p-6 rounded-2xl shadow-lg">
             <h3 className="text-xs font-bold text-slate-500 uppercase tracking-widest mb-4">Response Format</h3>
             <div className="bg-slate-950 rounded-xl p-4 font-mono text-[10px] border border-slate-800 relative">
                <div className="absolute top-2 right-2 flex gap-1">
                   <div className="w-2 h-2 rounded-full bg-red-500/30"></div>
                   <div className="w-2 h-2 rounded-full bg-amber-500/30"></div>
                   <div className="w-2 h-2 rounded-full bg-green-500/30"></div>
                </div>
                <pre className="text-blue-300 overflow-x-auto whitespace-pre-wrap leading-relaxed">
                   {errorHandling.standardResponse}
                </pre>
             </div>
             <p className="text-[10px] text-slate-600 mt-4 leading-relaxed">
                All API services must adhere to this JSON structure for consistency in frontend error handling and automated monitoring parsing.
             </p>
          </div>

          <div className="bg-indigo-900/10 border border-indigo-500/20 p-6 rounded-2xl shadow-lg">
             <h3 className="text-xs font-bold text-indigo-400 uppercase tracking-widest mb-4">Architect Best Practices</h3>
             <ul className="space-y-3">
                {[
                  "Use specific HTTP status codes (404, 429, 401)",
                  "Never leak raw database or environment errors",
                  "Enable cross-service correlation IDs for trace logs",
                  "Automate retry-ability for idempotent requests"
                ].map((item, i) => (
                  <li key={i} className="flex gap-3 items-start text-[11px] text-slate-400 leading-tight">
                     <span className="text-indigo-500 mt-0.5">✔</span>
                     {item}
                  </li>
                ))}
             </ul>
          </div>

          <div className="p-6 bg-slate-900 border border-slate-800 rounded-2xl">
             <button className="w-full py-2.5 bg-slate-800 hover:bg-slate-700 text-white text-xs font-bold rounded-lg transition-all flex items-center justify-center gap-2 border border-slate-700">
               <svg className="w-4 h-4 text-amber-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                 <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
               </svg>
               Export Error Specs
             </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ErrorLab;
