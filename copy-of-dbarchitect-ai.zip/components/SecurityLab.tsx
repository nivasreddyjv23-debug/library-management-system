
import React from 'react';
import { SchemaData } from '../types';

interface SecurityLabProps {
  data: SchemaData;
}

const SecurityLab: React.FC<SecurityLabProps> = ({ data }) => {
  const security = data.security;

  if (!security) {
    return (
      <div className="h-full flex items-center justify-center text-slate-500 italic border border-slate-800 rounded-xl bg-slate-900/20">
        No security specifications found in this blueprint.
      </div>
    );
  }

  const getControlColor = (type: string) => {
    switch (type) {
      case 'AuthN': return 'text-blue-400 bg-blue-500/10 border-blue-500/20';
      case 'AuthZ': return 'text-purple-400 bg-purple-500/10 border-purple-500/20';
      case 'Encryption': return 'text-emerald-400 bg-emerald-500/10 border-emerald-500/20';
      case 'Network': return 'text-amber-400 bg-amber-500/10 border-amber-500/20';
      case 'Audit': return 'text-rose-400 bg-rose-500/10 border-rose-500/20';
      default: return 'text-slate-400 bg-slate-800 border-slate-700';
    }
  };

  return (
    <div className="flex flex-col h-full gap-6 bg-slate-950 p-6 rounded-xl border border-slate-800 overflow-hidden shadow-2xl overflow-y-auto scrollbar-thin">
      <div className="flex items-center justify-between mb-2">
        <div>
          <h2 className="text-xl font-bold text-white flex items-center gap-2">
            <svg className="w-6 h-6 text-blue-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
            </svg>
            Security Architecture Blueprint
          </h2>
          <p className="text-sm text-slate-500 mt-1">Protocols, Authentication, and Access Control policies.</p>
        </div>
        <div className="flex gap-2">
           <span className="px-2 py-1 bg-emerald-500/10 border border-emerald-500/20 rounded text-[10px] font-bold text-emerald-500 uppercase tracking-widest">TLS 1.3 Mandatory</span>
           <span className="px-2 py-1 bg-blue-500/10 border border-blue-500/20 rounded text-[10px] font-bold text-blue-500 uppercase tracking-widest">Zero-Trust Model</span>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Core Strategy Cards */}
        <div className="lg:col-span-8 space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
             <div className="bg-slate-900 border border-slate-800 p-5 rounded-2xl">
                <div className="text-[10px] text-blue-500 font-bold uppercase tracking-widest mb-2">Authentication Strategy</div>
                <div className="text-sm font-bold text-slate-200 mb-2">{security.authentication.split(':')[0] || 'Identity Provider'}</div>
                <p className="text-xs text-slate-400 leading-relaxed italic">{security.authentication}</p>
             </div>
             <div className="bg-slate-900 border border-slate-800 p-5 rounded-2xl">
                <div className="text-[10px] text-purple-500 font-bold uppercase tracking-widest mb-2">Authorization Policy</div>
                <div className="text-sm font-bold text-slate-200 mb-2">{security.authorization.split(':')[0] || 'Access Control'}</div>
                <p className="text-xs text-slate-400 leading-relaxed italic">{security.authorization}</p>
             </div>
          </div>

          <div className="bg-slate-900 border border-slate-800 p-6 rounded-2xl shadow-lg">
             <h3 className="text-xs font-bold text-slate-500 uppercase tracking-widest mb-4">Defense-in-Depth Controls</h3>
             <div className="space-y-3">
                {security.controls.map((control, i) => (
                  <div key={i} className="bg-slate-950 p-4 rounded-xl border border-slate-800 flex items-start gap-4 hover:border-slate-700 transition-colors">
                    <div className={`px-2 py-1 rounded text-[9px] font-black uppercase tracking-tighter ${getControlColor(control.type)}`}>
                      {control.type}
                    </div>
                    <div className="flex-1">
                       <div className="text-sm font-bold text-slate-200">{control.name}</div>
                       <div className="text-[11px] text-slate-500 mt-1">{control.description}</div>
                       <div className="mt-3 bg-slate-900/50 p-2 rounded text-[10px] font-mono text-blue-400 border border-slate-800">
                          {control.implementation}
                       </div>
                    </div>
                  </div>
                ))}
             </div>
          </div>
        </div>

        {/* Sidebar: Data Security & RBAC */}
        <div className="lg:col-span-4 space-y-6">
          <div className="bg-slate-900 border border-slate-800 p-6 rounded-2xl shadow-lg">
             <h3 className="text-xs font-bold text-emerald-500 uppercase tracking-widest mb-4 flex items-center gap-2">
                <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                   <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
                </svg>
                Encryption Strategy
             </h3>
             <div className="bg-slate-950 p-4 rounded-xl border border-emerald-500/10 italic text-xs text-slate-400 leading-relaxed">
                {security.encryptionStrategy}
             </div>
             <div className="mt-4 flex flex-col gap-2">
                <div className="flex justify-between items-center text-[10px] text-slate-500">
                   <span>At Rest</span>
                   <span className="text-emerald-500 font-bold font-mono">AES-256-GCM</span>
                </div>
                <div className="flex justify-between items-center text-[10px] text-slate-500">
                   <span>In Transit</span>
                   <span className="text-emerald-500 font-bold font-mono">TLS 1.3 / HSTS</span>
                </div>
                <div className="flex justify-between items-center text-[10px] text-slate-500">
                   <span>Hashing</span>
                   <span className="text-emerald-500 font-bold font-mono">Argon2id (64MB)</span>
                </div>
             </div>
          </div>

          <div className="bg-slate-900 border border-slate-800 p-6 rounded-2xl shadow-lg">
             <h3 className="text-xs font-bold text-slate-500 uppercase tracking-widest mb-4">RBAC Permissions</h3>
             <div className="space-y-2">
                {data.apiEndpoints.filter(ep => ep.rolesRequired).slice(0, 5).map((ep, i) => (
                  <div key={i} className="flex items-center justify-between text-[11px] bg-slate-950 p-2 rounded border border-slate-800">
                    <span className="text-slate-400 font-mono truncate mr-2">{ep.path}</span>
                    <div className="flex gap-1">
                      {ep.rolesRequired?.map((role, idx) => (
                        <span key={idx} className="bg-blue-500/20 text-blue-400 px-1 rounded text-[9px] font-bold uppercase">{role}</span>
                      ))}
                    </div>
                  </div>
                ))}
                {data.apiEndpoints.filter(ep => ep.rolesRequired).length === 0 && (
                   <p className="text-[10px] text-slate-600 italic">No specific RBAC roles defined for current endpoints.</p>
                )}
             </div>
          </div>

          <div className="bg-rose-900/10 border border-rose-500/20 p-6 rounded-2xl">
             <h3 className="text-xs font-bold text-rose-500 uppercase tracking-widest mb-3">Vulnerability Mitigations</h3>
             <ul className="space-y-2">
                {[
                  "SQL Injection (Parameterized Queries)",
                  "XSS (Output Encoding / CSP)",
                  "CSRF (SameSite Cookies / Anti-Forgery Tokens)",
                  "Brute Force (Rate Limiting + Account Lockout)"
                ].map((item, i) => (
                  <li key={i} className="flex gap-2 items-start text-[10px] text-slate-400 leading-tight">
                     <span className="text-rose-500 mt-0.5">•</span>
                     {item}
                  </li>
                ))}
             </ul>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SecurityLab;
