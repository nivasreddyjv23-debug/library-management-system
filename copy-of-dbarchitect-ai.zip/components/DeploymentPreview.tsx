
import React, { useState, useEffect } from 'react';

interface LogEntry {
  timestamp: string;
  level: 'INFO' | 'SUCCESS' | 'WARN' | 'ERROR';
  message: string;
}

interface DeploymentPreviewProps {
  environment: 'staging' | 'production';
  onPromote?: () => void;
}

const DeploymentPreview: React.FC<DeploymentPreviewProps> = ({ environment, onPromote }) => {
  const [logs, setLogs] = useState<LogEntry[]>([]);
  const [progress, setProgress] = useState(0);
  const [status, setStatus] = useState<'IDLE' | 'BUILDING' | 'DEPLOYED'>('IDLE');

  const stagingSteps = [
    { message: "Initializing staging environment cluster...", delay: 500 },
    { message: "Pulling latest architecture blueprint (V1.0.5)...", delay: 1200 },
    { message: "Validating PostgreSQL schema integrity...", delay: 2000 },
    { message: "Provisioning AWS RDS instance (Staging)...", delay: 3500 },
    { message: "Compiling React frontend with production optimizations...", delay: 5000 },
    { message: "Starting Node.js API container (Docker)...", delay: 6500 },
    { message: "Injecting environment secrets...", delay: 7500 },
    { message: "Warming up Materialized Views & Cache layers...", delay: 8500 },
    { message: "Deployment successful. Staging URL: https://staging.dbarchitect.ai", delay: 10000, level: 'SUCCESS' as const },
  ];

  const productionSteps = [
    { message: "Initiating Production Cutover sequence...", delay: 500 },
    { message: "Running final UAT validation suite...", delay: 1200 },
    { message: "Snapshoting staging database for migration...", delay: 2500 },
    { message: "Scaling production cluster to 4 nodes...", delay: 4000 },
    { message: "Updating Global Load Balancer (Route53)...", delay: 5500 },
    { message: "Applying Zero-Downtime database migration...", delay: 7000 },
    { message: "Invalidating CloudFront CDN cache...", delay: 8500 },
    { message: "Production Deployment successful. LIVE URL: https://dbarchitect.ai", delay: 10000, level: 'SUCCESS' as const },
  ];

  useEffect(() => {
    setLogs([]);
    setProgress(0);
    setStatus('BUILDING');
    
    const steps = environment === 'production' ? productionSteps : stagingSteps;
    let currentLogIndex = 0;

    const interval = setInterval(() => {
      if (currentLogIndex < steps.length) {
        const step = steps[currentLogIndex];
        setLogs(prev => [...prev, {
          timestamp: new Date().toLocaleTimeString(),
          level: step.level || 'INFO',
          message: step.message
        }]);
        setProgress(Math.round(((currentLogIndex + 1) / steps.length) * 100));
        currentLogIndex++;
      } else {
        setStatus('DEPLOYED');
        clearInterval(interval);
      }
    }, 600);

    return () => clearInterval(interval);
  }, [environment]);

  const isProduction = environment === 'production';

  return (
    <div className={`flex flex-col h-full rounded-xl border overflow-hidden shadow-2xl font-mono transition-colors duration-700 ${isProduction ? 'bg-slate-950 border-blue-900/50' : 'bg-slate-950 border-slate-800'}`}>
      <div className={`flex items-center justify-between px-4 py-2 border-b transition-colors duration-700 ${isProduction ? 'bg-blue-900/20 border-blue-800/50' : 'bg-slate-900 border-slate-800'}`}>
        <div className="flex items-center gap-2">
          <div className={`w-2.5 h-2.5 rounded-full animate-pulse ${isProduction ? 'bg-blue-500 shadow-[0_0_8px_rgba(59,130,246,0.5)]' : 'bg-amber-500'}`}></div>
          <span className={`text-[10px] uppercase tracking-widest font-black ${isProduction ? 'text-blue-400' : 'text-slate-400'}`}>
            {environment} Environment Deployment
          </span>
        </div>
        <div className="flex items-center gap-4">
          <div className="text-[10px] text-slate-500">Node Status: <span className="text-emerald-500">ACTIVE</span></div>
          <div className={`px-2 py-0.5 rounded text-[10px] border font-bold ${isProduction ? 'bg-blue-500/10 text-blue-400 border-blue-500/20' : 'bg-slate-800/50 text-slate-400 border-slate-700'}`}>
            {isProduction ? 'us-east-1 (Global)' : 'us-east-1a'}
          </div>
        </div>
      </div>

      <div className="flex-1 p-6 overflow-y-auto space-y-2 scrollbar-thin">
        {logs.map((log, i) => (
          <div key={i} className="flex gap-4 text-xs animate-in fade-in slide-in-from-left-2 duration-300">
            <span className="text-slate-600 shrink-0">[{log.timestamp}]</span>
            <span className={
              log.level === 'SUCCESS' ? 'text-emerald-400 font-bold' : 
              log.level === 'WARN' ? 'text-amber-400' : 
              log.level === 'ERROR' ? 'text-red-400 font-bold' : 
              isProduction ? 'text-blue-400' : 'text-slate-400'
            }>
              {log.level}
            </span>
            <span className={log.level === 'SUCCESS' ? 'text-white' : 'text-slate-300'}>{log.message}</span>
          </div>
        ))}
        {status === 'BUILDING' && (
          <div className="flex items-center gap-2 text-xs text-slate-500 italic animate-pulse">
            <span className={`w-1 h-1 rounded-full ${isProduction ? 'bg-blue-500' : 'bg-slate-500'}`}></span>
            Applying infrastructure changes...
          </div>
        )}
      </div>

      <div className={`p-4 border-t transition-colors duration-700 ${isProduction ? 'bg-blue-900/10 border-blue-800/50' : 'bg-slate-900/50 border-slate-800'}`}>
        <div className="flex justify-between items-center mb-2">
          <span className="text-[10px] text-slate-500 font-bold uppercase tracking-widest">
            {isProduction ? 'Traffic Cutover' : 'Build Progress'}
          </span>
          <span className={`text-[10px] font-bold ${isProduction ? 'text-blue-400' : 'text-slate-400'}`}>{progress}%</span>
        </div>
        <div className="w-full h-1.5 bg-slate-900 rounded-full overflow-hidden border border-slate-800">
          <div 
            className={`h-full transition-all duration-500 ${isProduction ? 'bg-blue-500 shadow-[0_0_10px_rgba(59,130,246,0.3)]' : 'bg-blue-600'}`} 
            style={{ width: `${progress}%` }}
          ></div>
        </div>
        
        <div className="mt-4 flex items-center justify-between">
          <div className="flex gap-4">
            <div className="bg-slate-800/30 p-3 rounded-lg border border-slate-800 min-w-[100px]">
              <div className="text-[9px] text-slate-500 uppercase mb-1">Status</div>
              <div className={`text-[10px] font-bold ${status === 'DEPLOYED' ? 'text-emerald-400' : 'text-amber-400'}`}>
                {status === 'DEPLOYED' ? '● HEALTHY' : '○ DEPLOYING'}
              </div>
            </div>
            <div className="bg-slate-800/30 p-3 rounded-lg border border-slate-800 min-w-[100px]">
              <div className="text-[9px] text-slate-500 uppercase mb-1">Availability</div>
              <div className="text-[10px] font-bold text-slate-300">{isProduction ? '99.99%' : '99.90%'}</div>
            </div>
          </div>

          {status === 'DEPLOYED' && !isProduction && onPromote && (
            <button 
              onClick={onPromote}
              className="px-6 py-3 bg-blue-600 hover:bg-blue-500 text-white rounded-xl shadow-lg shadow-blue-500/20 transition-all flex items-center gap-3 animate-in zoom-in duration-500"
            >
              <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 11l7-7m0 0l7 7m-7-7v18" />
              </svg>
              <div className="text-left">
                <div className="text-xs font-bold leading-none">Promote to Production</div>
                <div className="text-[9px] opacity-70 uppercase tracking-tighter">Zero-downtime cutover</div>
              </div>
            </button>
          )}

          {status === 'DEPLOYED' && isProduction && (
            <div className="flex items-center gap-2 px-4 py-2 bg-emerald-500/10 border border-emerald-500/20 rounded-lg animate-in zoom-in duration-500">
               <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
               <span className="text-[10px] font-bold text-emerald-500 uppercase tracking-widest">Live in Production</span>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default DeploymentPreview;
