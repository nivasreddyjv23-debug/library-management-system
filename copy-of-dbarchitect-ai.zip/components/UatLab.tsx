
import React, { useState } from 'react';
import { SchemaData } from '../types';

interface UatLabProps {
  data: SchemaData;
  onRefine?: (feedback: FeedbackEntry[]) => void;
  isRefining?: boolean;
}

export interface FeedbackEntry {
  id: string;
  tester: string;
  role: 'Librarian' | 'Staff' | 'Member';
  scenario: string;
  status: 'PASS' | 'FAIL' | 'REVISION';
  comment: string;
  timestamp: string;
}

const UatLab: React.FC<UatLabProps> = ({ data, onRefine, isRefining }) => {
  const [feedback, setFeedback] = useState<FeedbackEntry[]>([]);
  const [activeTester, setActiveTester] = useState<string>('');
  const [activeRole, setActiveRole] = useState<'Librarian' | 'Staff' | 'Member'>('Librarian');

  const scenarios = [
    { id: 'S1', title: 'Book Catalog Search', description: 'Test the responsiveness and accuracy of the cached book search results.' },
    { id: 'S2', title: 'Member Loan Eligibility', description: 'Verify that the system correctly identifies overdue loans before allowing new check-outs.' },
    { id: 'S3', title: 'Real-time Availability', description: 'Ensure book status updates immediately across the library network.' },
    { id: 'S4', title: 'Performance under Load', description: 'Simulate 50+ simultaneous search queries using the materialized view architecture.' }
  ];

  const handleLogFeedback = (scenario: string, status: 'PASS' | 'FAIL' | 'REVISION', comment: string) => {
    if (!activeTester) {
      alert("Please enter a tester name first.");
      return;
    }
    const newEntry: FeedbackEntry = {
      id: Math.random().toString(36).substr(2, 9),
      tester: activeTester,
      role: activeRole,
      scenario,
      status,
      comment,
      timestamp: new Date().toLocaleTimeString()
    };
    setFeedback([newEntry, ...feedback]);
  };

  const criticalFeedbackCount = feedback.filter(f => f.status !== 'PASS').length;

  return (
    <div className="flex h-full gap-6">
      {/* Test Scenarios & Prototype View */}
      <div className="flex-1 flex flex-col gap-6">
        <div className="bg-slate-900 rounded-xl border border-slate-800 p-6 shadow-xl relative overflow-hidden">
          {isRefining && (
            <div className="absolute inset-0 bg-slate-900/80 backdrop-blur-sm z-50 flex flex-col items-center justify-center animate-in fade-in duration-300">
               <div className="w-8 h-8 border-2 border-blue-500 border-t-transparent rounded-full animate-spin mb-4"></div>
               <span className="text-xs font-bold text-blue-400 uppercase tracking-widest">Architect Refinement in Progress...</span>
            </div>
          )}
          
          <div className="flex items-center justify-between mb-6">
            <div>
              <h2 className="text-lg font-bold text-white">Library UAT Lab</h2>
              <p className="text-xs text-slate-500">Live Architecture Validation & User Acceptance</p>
            </div>
            <div className="flex gap-2">
              <input 
                type="text" 
                placeholder="Tester Name" 
                value={activeTester}
                onChange={(e) => setActiveTester(e.target.value)}
                className="bg-slate-800 border border-slate-700 rounded-lg px-3 py-1.5 text-xs focus:outline-none focus:ring-1 focus:ring-blue-500 text-slate-200"
              />
              <select 
                value={activeRole}
                onChange={(e) => setActiveRole(e.target.value as any)}
                className="bg-slate-800 border border-slate-700 rounded-lg px-3 py-1.5 text-xs focus:outline-none focus:ring-1 focus:ring-blue-500 text-slate-200"
              >
                <option>Librarian</option>
                <option>Staff</option>
                <option>Member</option>
              </select>
            </div>
          </div>

          <div className="space-y-4 max-h-[400px] overflow-y-auto pr-2 scrollbar-thin">
            {scenarios.map(s => (
              <div key={s.id} className="bg-slate-950/50 border border-slate-800 rounded-xl p-4 hover:border-slate-700 transition-colors">
                <div className="flex justify-between items-start mb-2">
                  <h3 className="text-sm font-bold text-slate-200">{s.title}</h3>
                  <span className="text-[10px] font-mono text-slate-600 tracking-tighter bg-slate-900 px-2 py-0.5 rounded uppercase">{s.id}</span>
                </div>
                <p className="text-xs text-slate-500 mb-4 leading-relaxed">{s.description}</p>
                
                <div className="flex items-center gap-3">
                  <button 
                    onClick={() => handleLogFeedback(s.title, 'PASS', 'Scenario completed as expected.')}
                    className="flex-1 py-1.5 bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-500 text-[10px] font-bold rounded border border-emerald-500/20 uppercase tracking-widest transition-all"
                  >
                    Pass
                  </button>
                  <button 
                    onClick={() => {
                      const comment = prompt("Enter revision requirements:");
                      if (comment) handleLogFeedback(s.title, 'REVISION', comment);
                    }}
                    className="flex-1 py-1.5 bg-amber-500/10 hover:bg-amber-500/20 text-amber-500 text-[10px] font-bold rounded border border-amber-500/20 uppercase tracking-widest transition-all"
                  >
                    Revision
                  </button>
                  <button 
                    onClick={() => {
                      const comment = prompt("Describe the bug/failure:");
                      if (comment) handleLogFeedback(s.title, 'FAIL', comment);
                    }}
                    className="flex-1 py-1.5 bg-red-500/10 hover:bg-red-500/20 text-red-500 text-[10px] font-bold rounded border border-red-500/20 uppercase tracking-widest transition-all"
                  >
                    Fail
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Real-time UAT Status Dashboard */}
        <div className="bg-slate-900/50 rounded-xl border border-slate-800 p-6 flex items-center justify-between">
          <div className="flex gap-8">
            <div className="text-center">
              <div className="text-2xl font-bold text-emerald-400">{feedback.filter(f => f.status === 'PASS').length}</div>
              <div className="text-[10px] text-slate-500 uppercase font-bold">Passed</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-amber-400">{feedback.filter(f => f.status === 'REVISION').length}</div>
              <div className="text-[10px] text-slate-500 uppercase font-bold">Revision</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-red-400">{feedback.filter(f => f.status === 'FAIL').length}</div>
              <div className="text-[10px] text-slate-500 uppercase font-bold">Failed</div>
            </div>
          </div>
          
          {criticalFeedbackCount > 0 && onRefine && (
            <button 
              onClick={() => onRefine(feedback)}
              disabled={isRefining}
              className="px-6 py-3 bg-blue-600 hover:bg-blue-500 disabled:opacity-50 text-white rounded-xl shadow-lg shadow-blue-500/20 transition-all flex items-center gap-3 animate-pulse"
            >
              <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
              </svg>
              <div className="text-left">
                <div className="text-xs font-bold leading-none">Apply Adjustments</div>
                <div className="text-[9px] opacity-70">Resolve {criticalFeedbackCount} critical issues</div>
              </div>
            </button>
          )}
          
          <div className="text-right">
            <div className="text-xs font-bold text-slate-400">Architecture Readiness</div>
            <div className="text-xl font-bold text-blue-400">
               {feedback.length > 0 ? Math.round((feedback.filter(f => f.status === 'PASS').length / feedback.length) * 100) : 0}%
            </div>
          </div>
        </div>
      </div>

      {/* Feedback Feed */}
      <div className="w-80 flex flex-col bg-slate-900 rounded-xl border border-slate-800 overflow-hidden shadow-2xl">
        <div className="px-4 py-3 bg-slate-800/50 border-b border-slate-800 flex items-center justify-between">
          <span className="text-xs font-bold text-white uppercase tracking-widest">UAT Feedback Log</span>
          <span className="text-[10px] text-slate-500 font-mono">{feedback.length}</span>
        </div>
        <div className="flex-1 overflow-y-auto p-4 space-y-4 scrollbar-thin">
          {feedback.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center text-slate-600 text-center px-4">
              <svg className="w-10 h-10 mb-2 opacity-20" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M8 10h.01M12 10h.01M16 10h.01M9 16H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-5l-5 5v-5z" />
              </svg>
              <p className="text-xs">Waiting for testers to log feedback...</p>
            </div>
          ) : (
            feedback.map(entry => (
              <div key={entry.id} className="bg-slate-950 rounded-lg p-3 border-l-2 border-slate-800 transition-all animate-in slide-in-from-right-2" style={{ borderLeftColor: entry.status === 'PASS' ? '#10b981' : entry.status === 'REVISION' ? '#f59e0b' : '#ef4444' }}>
                <div className="flex items-center justify-between mb-1">
                  <span className="text-[10px] font-bold text-slate-300">{entry.tester} <span className="text-slate-600 font-normal">({entry.role})</span></span>
                  <span className="text-[10px] text-slate-600">{entry.timestamp}</span>
                </div>
                <div className="text-[10px] text-slate-400 font-medium mb-1 uppercase tracking-tighter">{entry.scenario}</div>
                <p className="text-[11px] text-slate-300 leading-tight italic">"{entry.comment}"</p>
              </div>
            ))
          )}
        </div>
        <div className="p-4 bg-slate-800/20 border-t border-slate-800">
           <button className="w-full py-2 bg-slate-700 hover:bg-slate-600 text-white text-xs font-bold rounded-lg transition-all flex items-center justify-center gap-2">
             <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
               <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
             </svg>
             Export UAT Report
           </button>
        </div>
      </div>
    </div>
  );
};

export default UatLab;
