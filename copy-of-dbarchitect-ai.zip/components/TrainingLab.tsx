
import React, { useState, useEffect } from 'react';
import { SchemaData, ManualSection } from '../types';
import FrontendPreview from './FrontendPreview';

interface TrainingLabProps {
  data: SchemaData;
}

interface TrainingTask {
  id: string;
  title: string;
  description: string;
  completed: boolean;
}

const TrainingLab: React.FC<TrainingLabProps> = ({ data }) => {
  const [mode, setMode] = useState<'reading' | 'interactive'>('reading');
  const [selectedAudience, setSelectedAudience] = useState<'Developer' | 'Admin' | 'End-User'>('End-User');
  const [activeSection, setActiveSection] = useState<number>(0);
  
  // Interactive Session State
  const [tasks, setTasks] = useState<TrainingTask[]>([
    { id: '1', title: 'Search for a Book', description: 'Use the search bar to find "The Great Gatsby" and observe the cache status.', completed: false },
    { id: '2', title: 'Check Out Process', description: 'Navigate to the loan dashboard and initiate a check-out for a dummy member.', completed: false },
    { id: '3', title: 'Review Overdue List', description: 'Check the reporting section for any overdue items highlighted by the system.', completed: false },
    { id: '4', title: 'System Heartbeat', description: 'Verify the database connection health indicator in the footer.', completed: false },
  ]);

  const toggleTask = (id: string) => {
    setTasks(prev => prev.map(t => t.id === id ? { ...t, completed: !t.completed } : t));
  };

  const progress = Math.round((tasks.filter(t => t.completed).length / tasks.length) * 100);
  const filteredManual = data.manual?.filter(m => m.audience === selectedAudience) || [];

  return (
    <div className="flex flex-col h-full bg-slate-950 rounded-xl border border-slate-800 overflow-hidden shadow-2xl">
      {/* Top Header Toggle */}
      <div className="flex items-center justify-between px-6 py-3 bg-slate-900 border-b border-slate-800">
        <div className="flex items-center gap-4">
          <button 
            onClick={() => setMode('reading')}
            className={`px-4 py-1.5 rounded-lg text-xs font-bold transition-all ${mode === 'reading' ? 'bg-blue-600 text-white shadow-lg shadow-blue-900/40' : 'text-slate-500 hover:text-slate-300'}`}
          >
            DOCUMENTATION
          </button>
          <button 
            onClick={() => setMode('interactive')}
            className={`px-4 py-1.5 rounded-lg text-xs font-bold transition-all ${mode === 'interactive' ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-900/40' : 'text-slate-500 hover:text-slate-300'}`}
          >
            LIVE TRAINING SESSION
          </button>
        </div>
        <div className="flex items-center gap-3">
          <div className="text-right">
            <div className="text-[10px] text-slate-500 uppercase font-black tracking-widest">Training Progress</div>
            <div className="text-xs font-mono text-blue-400 font-bold">{progress}% Certified</div>
          </div>
          <div className="w-24 h-1.5 bg-slate-800 rounded-full overflow-hidden">
            <div className="h-full bg-blue-500 transition-all duration-500" style={{ width: `${progress}%` }}></div>
          </div>
        </div>
      </div>

      <div className="flex-1 flex overflow-hidden">
        {mode === 'reading' ? (
          <>
            {/* Sidebar Navigation */}
            <div className="w-64 border-r border-slate-800 bg-slate-900/30 flex flex-col">
              <div className="p-4 border-b border-slate-800">
                <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest block mb-2">View Persona</label>
                <div className="grid grid-cols-1 gap-1">
                  {(['End-User', 'Admin', 'Developer'] as const).map(role => (
                    <button
                      key={role}
                      onClick={() => {
                        setSelectedAudience(role);
                        setActiveSection(0);
                      }}
                      className={`text-left px-3 py-2 rounded-lg text-xs font-semibold transition-all ${
                        selectedAudience === role 
                        ? 'bg-blue-600/20 text-blue-400 border border-blue-500/30' 
                        : 'text-slate-400 hover:bg-slate-800 hover:text-slate-200'
                      }`}
                    >
                      {role === 'End-User' ? 'Librarian (End-User)' : role}
                    </button>
                  ))}
                </div>
              </div>
              
              <div className="flex-1 overflow-y-auto p-2 scrollbar-thin">
                <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest block mb-2 px-2 mt-4">Manual Sections</label>
                {filteredManual.map((section, idx) => (
                  <button
                    key={idx}
                    onClick={() => setActiveSection(idx)}
                    className={`w-full text-left px-3 py-2.5 rounded-lg text-[11px] leading-tight transition-all mb-1 ${
                      activeSection === idx 
                      ? 'bg-slate-800 text-blue-400 border border-blue-500/20' 
                      : 'text-slate-500 hover:text-slate-300'
                    }`}
                  >
                    {section.title}
                  </button>
                ))}
              </div>
            </div>

            {/* Content Area */}
            <div className="flex-1 bg-slate-950 overflow-y-auto scrollbar-thin">
              {filteredManual[activeSection] ? (
                <div className="p-10 max-w-3xl mx-auto w-full">
                  <div className="mb-8">
                    <span className="text-[10px] font-bold text-blue-500 bg-blue-500/10 px-2 py-0.5 rounded uppercase tracking-widest border border-blue-500/20">
                      {selectedAudience} Module
                    </span>
                    <h1 className="text-3xl font-bold text-white mt-4 tracking-tight">{filteredManual[activeSection].title}</h1>
                  </div>
                  
                  <div className="prose prose-invert prose-slate max-w-none text-slate-300 text-sm leading-relaxed space-y-4">
                    {filteredManual[activeSection].content.split('\n').map((line, i) => {
                      if (line.startsWith('#')) {
                         const level = line.match(/^#+/)?.[0].length || 1;
                         const text = line.replace(/^#+\s*/, '');
                         return <h2 key={i} className={`font-bold text-white mt-6 mb-2 ${level === 2 ? 'text-xl' : 'text-lg'}`}>{text}</h2>;
                      }
                      if (line.startsWith('- ') || line.startsWith('* ')) {
                        return <li key={i} className="ml-4 list-disc marker:text-blue-500 mb-1">{line.substring(2)}</li>;
                      }
                      if (line.trim() === '') return <br key={i} />;
                      return <p key={i}>{line}</p>;
                    })}
                  </div>
                </div>
              ) : (
                <div className="h-full flex flex-col items-center justify-center text-slate-600">
                   <p className="text-sm">Select a section to begin reading.</p>
                </div>
              )}
            </div>
          </>
        ) : (
          <div className="flex-1 flex overflow-hidden">
            {/* Interactive Tasks Sidebar */}
            <div className="w-80 border-r border-slate-800 bg-slate-900/50 flex flex-col">
              <div className="p-4 border-b border-slate-800 bg-slate-900">
                 <h3 className="text-xs font-bold text-white uppercase tracking-widest">Training Syllabus</h3>
                 <p className="text-[10px] text-slate-500 mt-1">Complete these tasks in the live preview to master the system.</p>
              </div>
              <div className="flex-1 overflow-y-auto p-4 space-y-3 scrollbar-thin">
                {tasks.map(task => (
                  <div 
                    key={task.id} 
                    onClick={() => toggleTask(task.id)}
                    className={`p-3 rounded-xl border transition-all cursor-pointer group ${task.completed ? 'bg-emerald-500/10 border-emerald-500/30' : 'bg-slate-800 border-slate-700 hover:border-slate-600'}`}
                  >
                    <div className="flex items-center gap-3">
                      <div className={`w-5 h-5 rounded-full border-2 flex items-center justify-center shrink-0 transition-colors ${task.completed ? 'bg-emerald-500 border-emerald-500' : 'border-slate-600 group-hover:border-slate-500'}`}>
                        {task.completed && (
                          <svg className="w-3 h-3 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" />
                          </svg>
                        )}
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className={`text-xs font-bold ${task.completed ? 'text-emerald-400 line-through' : 'text-slate-200'}`}>{task.title}</div>
                        <p className="text-[10px] text-slate-500 mt-1 leading-tight">{task.description}</p>
                      </div>
                    </div>
                  </div>
                ))}

                {progress === 100 && (
                  <div className="p-6 bg-indigo-600 rounded-xl text-center shadow-xl shadow-indigo-900/40 animate-in zoom-in duration-500">
                    <div className="w-12 h-12 bg-white/20 rounded-full flex items-center justify-center mx-auto mb-3">
                      <svg className="w-6 h-6 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                      </svg>
                    </div>
                    <div className="text-sm font-bold text-white">Certification Earned!</div>
                    <p className="text-[10px] text-indigo-100 mt-1">You are now officially certified in the new Library Management System.</p>
                    <button className="mt-4 w-full py-1.5 bg-white text-indigo-600 text-[10px] font-bold rounded-lg uppercase tracking-widest hover:bg-indigo-50 transition-all">
                      View Certificate
                    </button>
                  </div>
                )}
              </div>
            </div>

            {/* Hands-on Preview */}
            <div className="flex-1 bg-slate-950 p-6 flex flex-col gap-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                   <div className="w-2 h-2 rounded-full bg-indigo-500 animate-pulse"></div>
                   <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Interactive Playground</span>
                </div>
                <div className="text-[10px] text-slate-600 italic">This environment uses live mock-up state for training.</div>
              </div>
              <div className="flex-1 border border-slate-800 rounded-2xl overflow-hidden shadow-2xl">
                {data.frontendCode ? (
                  <FrontendPreview 
                    code={data.frontendCode} 
                    title="LiveTrainingEnvironment.tsx" 
                  />
                ) : (
                  <div className="h-full flex items-center justify-center text-slate-600">
                    Frontend prototype required for interactive session.
                  </div>
                )}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default TrainingLab;
